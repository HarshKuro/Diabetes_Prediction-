#!/bin/bash

# Basic arithmetic within double parentheses
a=10
b=3
sum=$((a + b))
difference=$((a - b))
product=$((a * b))
quotient=$((a / b)) # Integer division
remainder=$((a % b))

# Output using echo
echo "Sum: $sum"
echo "Difference: $difference"
echo "Product: $product"
echo "Quotient: $quotient"
echo "Remainder: $remainder"
