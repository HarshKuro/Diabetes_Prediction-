#!/bin/bash

echo "Script name: $0"
echo "All arguments: $*"
echo "All arguments individually quoted: $@"
echo "Number of arguments: $#"

if [ $# -ge 2 ]; then
    echo "Second argument: $2"
fi

if [ $# -gt 0 ]; then
    echo "Last argument: ${!}" 
fi
