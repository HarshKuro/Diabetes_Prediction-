#include <stdio.h>
#include <fcntl.h> 
#include <unistd.h>
#include <string.h>

int main() {
    // 1. Create a new file (or truncate an existing one)
    int fd_create = open("new_file.txt", O_CREAT | O_WRONLY | O_TRUNC, 0644); 
    if (fd_create == -1) {
        perror("Error creating file");
        return 1;
    }

    // 2. Write some data to the file
    const char* message = "Hello from the newly created file!\n";
    ssize_t bytes_written = write(fd_create, message, strlen(message));
    if (bytes_written == -1) {
        perror("Error writing to file");
        close(fd_create); // Important to close even on error
        return 1;
    }

    // 3. Close the file descriptor
    close(fd_create); 

    // 4. Open the file for reading
    int fd_read = open("new_file.txt", O_RDONLY);
    if (fd_read == -1) {
        perror("Error opening file for reading");
        return 1;
    }

    // 5. Read from the file
    char buffer[100]; 
    ssize_t bytes_read = read(fd_read, buffer, sizeof(buffer) - 1);
    if (bytes_read == -1) {
        perror("Error reading from file");
        close(fd_read); 
        return 1;
    }

    // 6. Null-terminate the buffer and print the read data
    buffer[bytes_read] = '\0';
    printf("Read from file: %s", buffer);

    // 7. Close the file descriptor
    close(fd_read);

    return 0;
}
