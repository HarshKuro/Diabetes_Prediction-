#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>

int main() {
    pid_t pid = fork();

    if (pid < 0) {
        perror("Fork failed");
        return 1;
    } else if (pid == 0) {
        // Child process
        int fd = open("child_data.txt", O_CREAT | O_WRONLY | O_TRUNC, 0644);
        if (fd == -1) {
            perror("Error opening file");
            exit(1);
        }

        dprintf(fd, "Data from the child process (PID %d)\n", getpid());
        close(fd);
        exit(0);
    } else {
        // Parent process
        wait(NULL); // Wait for any child to finish

        int fd = open("child_data.txt", O_RDONLY);
        if (fd == -1) {
            perror("Error opening file");
            return 1;
        }

        char buffer[100];
        ssize_t bytes_read = read(fd, buffer, sizeof(buffer) - 1);
        if (bytes_read > 0) {
            buffer[bytes_read] = '\0';
            printf("Parent read from file: %s", buffer);
        }

        close(fd);
    }

    return 0;
}
